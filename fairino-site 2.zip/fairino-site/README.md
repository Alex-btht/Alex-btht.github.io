# FAIRINO France — Site Web
## 📁 Structure des fichiers

```
fairino-site/
├── index.html                   ← Fichier principal du site
└── images/
    ├── logo.png                 ← Logo FAIRINO (noir sur blanc)
    ├── logo-orange.png          ← Logo FAIRINO FRANCE (fond orange)
    ├── gamme-complete.png       ← Photo de la gamme complète FR3→FR30
    ├── hero.jpg                 ← Image fond de la section d'accueil (1920×900px recommandé)
    ├── about-bg.jpg             ← Image fond section "À propos" (1600×700px recommandé)
    ├── cobot-action.jpg         ← Image cobot en action (optionnel, si vous l'ajoutez)
    │
    ├── cobots/
    │   ├── fr3.jpg              ← Photo du robot FR3 (600×500px recommandé)
    │   ├── fr5.jpg              ← Photo du robot FR5
    │   ├── fr10.jpg             ← Photo du robot FR10
    │   ├── fr16.jpg             ← Photo du robot FR16
    │   ├── fr20.jpg             ← Photo du robot FR20
    │   ├── fr30.jpg             ← Photo du robot FR30
    │   └── fr30l.jpg            ← Photo du robot FR30L (prochainement)
    │
    ├── applications/
    │   ├── soudage.jpg          ← Photo application soudage (800×600px recommandé)
    │   ├── palettisation.jpg    ← Photo application palettisation
    │   ├── assemblage.jpg       ← Photo application assemblage
    │   ├── vissage.jpg          ← Photo application vissage
    │   ├── controle-qualite.jpg ← Photo contrôle qualité vision
    │   └── manutention.jpg      ← Photo manutention industrielle
    │
    └── equipments/
        ├── pince-robotique.jpg  ← Photo pince robotique (600×450px recommandé)
        ├── vision-3d.jpg        ← Photo système vision 3D
        ├── capteur-force.jpg    ← Photo capteur force/couple
        ├── agv.jpg              ← Photo AGV/AMR
        ├── rail-lineaire.jpg    ← Photo rail linéaire
        └── brides-outil.jpg     ← Photo brides et outils
```

---

## 🖼️ Comment remplacer les images

**Il suffit de remplacer les fichiers `.jpg` dans les dossiers correspondants.**

✅ Respectez exactement les **noms de fichiers** (fr3.jpg, hero.jpg, etc.)
✅ Utilisez le format **JPEG** (.jpg)  
✅ Tailles recommandées indiquées ci-dessus, mais le site s'adapte automatiquement
✅ Pour les cobots, un fond blanc ou gris clair rend bien
✅ Pour les applications, des photos en situation (en atelier) sont idéales

---

## 🔐 Gérer les comptes partenaires

Ouvrez `index.html` avec un éditeur de texte (Notepad, VS Code...) et modifiez la section en haut du fichier :

```javascript
const PARTNER_ACCOUNTS = [
  { id: "demo",          pass: "FAIRINO2025", name: "Démo Partenaire",   level: "Gold"     },
  { id: "partenaire1",   pass: "motdepasse1", name: "Société Exemple 1", level: "Silver"   },
  { id: "partenaire2",   pass: "motdepasse2", name: "Société Exemple 2", level: "Platinum" },
  // Ajoutez vos partenaires ici :
  // { id: "email@societe.fr", pass: "motdepasse", name: "Nom Société", level: "Gold" },
];
```

**Niveaux disponibles :** `Silver`, `Gold`, `Platinum`

---

## 💰 Modifier les tarifs partenaires

Dans la même section, modifiez `PARTNER_PRICES` :

```javascript
const PARTNER_PRICES = {
  Silver: {
    FR3: { public: "4 600 €", partner: "3 910 €", discount: "−15%" },
    // ...
  },
  Gold: { ... },
  Platinum: { ... }
};
```

---

## 🌐 Héberger le site

### Option 1 — Netlify (gratuit, le plus simple)
1. Allez sur https://netlify.com
2. Glissez-déposez le **dossier fairino-site** entier sur Netlify
3. Votre site est en ligne instantanément !

### Option 2 — GitHub Pages (gratuit)
1. Créez un dépôt GitHub
2. Uploadez tous les fichiers du dossier `fairino-site`
3. Activez GitHub Pages dans Settings > Pages

### Option 3 — OVH / hébergement traditionnel
1. Connectez-vous via FTP (FileZilla)
2. Uploadez le contenu du dossier `fairino-site` dans `public_html/`
3. `index.html` doit être à la racine de `public_html/`

### ⚠️ Important
- Uploadez **tout le dossier** (index.html + images/) ensemble
- Le dossier `images/` doit être au même niveau que `index.html`

---

## 📞 Coordonnées à personnaliser dans index.html

Cherchez ces lignes et remplacez :
- `+33 1 70 00 00 00` → votre numéro de téléphone
- `support@fairino.fr` → votre email support
- `partenaires@fairino.fr` → votre email partenaires

---

*Site créé pour FAIRINO France — 2026 par Alexandre BERTHAULT*
